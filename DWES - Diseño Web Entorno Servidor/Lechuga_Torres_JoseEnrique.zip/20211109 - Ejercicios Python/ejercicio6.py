
ano = input("Introduce un año")

persona1 = input("Introduce nombre de persona 1 ")
ano1 = input("Introduce año nacimiento persona 1 ")
persona2 = input("Introduce nombre de persona 2 ")
ano2 = input("Introduce año nacimiento persona 2 ")
persona3 = input("Introduce nombre de persona 3 ")
ano3 = input("Introduce año nacimiento persona 3 ")

anos1 = int(ano)-int(ano1)
anos2 = int(ano)-int(ano2)
anos3 = int(ano)-int(ano3)


print("La persona 1 cumplira "+ str(anos1)+" en el año "+str(ano))
print("La persona 2 cumplira "+ str(anos2)+" en el año "+str(ano))
print("La persona 3 cumplira "+ str(anos3)+" en el año "+str(ano))