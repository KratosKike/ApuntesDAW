<?php
echo("Intentelo de nuevo");
echo("</br><a href='ejercicio2.html'>Volver</a>")

?>
