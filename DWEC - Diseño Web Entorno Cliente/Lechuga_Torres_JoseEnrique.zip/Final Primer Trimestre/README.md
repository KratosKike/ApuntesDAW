registro funcional, usuario metido por defecto
user:kike
pass:123