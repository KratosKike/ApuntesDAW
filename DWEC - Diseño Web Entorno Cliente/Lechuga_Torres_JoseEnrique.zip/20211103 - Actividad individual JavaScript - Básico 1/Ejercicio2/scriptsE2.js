alert("hola que tal hola que tal\nhola que tal hola que tal\"hola que tal hola que tal\'hola que tal hola que tal\bhola que tal hola que tal\thola que tal hola que tal");
