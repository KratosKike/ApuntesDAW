var iLado1 = prompt("Introduce primer valor");

var iLado2 = prompt("Introduce segundo valor");

var iRes = eval(iLado1*iLado2);

document.write(iRes);

