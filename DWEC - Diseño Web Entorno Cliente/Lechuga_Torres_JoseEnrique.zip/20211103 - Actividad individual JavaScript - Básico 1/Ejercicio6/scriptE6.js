var sNombre = prompt("Introduce tu nombre");
var iRepeticiones = prompt("Indique numero de repeticiones");

for (var irep=0;irep <iRepeticiones;irep++){
    document.write(sNombre+"</br>");
}