var iNumero = prompt("Introduce un numero");

alert("El numero es "+iNumero);

if(iNumero == 100){
    alert("El numero es "+iNumero);
}else if(iNumero == 200){
    alert("El numero es "+iNumero);
}else{
    alert("El numero no es ni 100 ni 200");
}

if(iNumero<0){
    alert("El numero es negativo");
}else{
    alert("El numero es positivo");
}